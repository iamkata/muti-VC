//
//  MainRoute.h
//  EOCCarClass
//
//  Created by sy on 2017/10/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainRoute : NSObject


- (void)skipToMenu:(NSNumber*)index;

@end
