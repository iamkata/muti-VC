//
//  EOCBaseNavCtr.h
//  EOCJinDong
//
//  Created by sunyong on 17/2/2.
//  Copyright © 2017年 @八点钟学院. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EOCBaseNavCtr : UINavigationController

@end
