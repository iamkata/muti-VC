//
//  EOCBaseNavCtr.m
//  EOCJinDong
//
//  Created by sunyong on 17/2/2.
//  Copyright © 2017年 @八点钟学院. All rights reserved.
//

#import "EOCBaseNavCtr.h"
#define RGB(X,Y,Z) [UIColor colorWithRed:X/255.0 green:Y/255.0 blue:Z/255.0 alpha:1]

@interface EOCBaseNavCtr ()

@end

@implementation EOCBaseNavCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return [self.visibleViewController preferredStatusBarStyle];
}

-(BOOL)prefersStatusBarHidden{
    return [self.visibleViewController prefersStatusBarHidden];
}

- (nullable NSArray<__kindof UIViewController *> *)popToRootViewControllerAnimated:(BOOL)animated{
    
    self.hidesBottomBarWhenPushed = NO;
    return [super popToRootViewControllerAnimated:animated];
}

//重写push方法, 设置hidesBottomBarWhenPushed
-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if (self.viewControllers.count) {
        viewController.hidesBottomBarWhenPushed = YES;
    }
    [super pushViewController:viewController animated:animated];
}

//还原
-(UIViewController *)popViewControllerAnimated:(BOOL)animated{

    if (self.viewControllers.count == 2) {
        self.hidesBottomBarWhenPushed = NO;
    }
    return [super popViewControllerAnimated:animated];
}

@end
