//
//  RecommendVCtr.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import "RecommendVCtr.h"
#import "RecommendCell.h"
#import "RecommendTopNewCell.h"
#import "RecommendViewModel.h"
#import "MessageDetailViewCtr.h"
#import "MessageModel.h"
#import "ReTableViewModel.h"
#import "ReMenuMoreVCtr.h"

/*
 V - VM
 MVCC (多控制器)addChildViewController
 
 对业务的拆分（细分c）
 */
@interface RecommendVCtr ()

@property (nonatomic, strong)RecommendViewModel *recomendViewModel;
@property (nonatomic, strong)ReTableViewModel *reTableViewModel;

@end

@implementation RecommendVCtr{
    
    ReMenuMoreVCtr *_reMenuMoreVCtr;
}


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    //self addChildViewController:<#(nonnull UIViewController *)#>
    self.automaticallyAdjustsScrollViewInsets = NO;
    [_headView removeFromSuperview];
    [_tableView setTableHeaderView:_headView];
    
    //[self.reTableViewModel configTable:_tableView];
    
    
    UITableView *tmpTableV = _tableView;
    // 下载数据业务
    [self.recomendViewModel loadDatafromNetWithPage:1 finishNet:^(id infoDict) {
        [tmpTableV reloadData];
    }];
}

- (void)viewDidLayoutSubviews{
    
    [super viewDidLayoutSubviews];
    [self.view bringSubviewToFront:_tableView];
    _tableView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - SysNavHeigh - SysTabBarHeigh);

}

- (IBAction)removeSelectV:(UIButton*)sender{
    
    [self.recomendViewModel deleteAdView:_isDeleteAdView headView:_headView tableview:_tableView];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    // return [RecommendCell cellHeight];
    return 80.0;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.recomendViewModel.rowNumber;
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    RecommendCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RecommendCell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"RecommendCell" owner:nil options:nil] firstObject];
    }
    
     cell.messageModel = [self messageModelForRow:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
     [self.recomendViewModel pushMessageDetailIndex:indexPath viewCtr:self];
}


- (MessageModel*)messageModelForRow:(NSInteger)row{
    
    //    if (row < self.messageAry.count) {
    //        return self.messageAry[row];
    //    }else{
    //        NSLog(@"row越界messageAry：%ld--%ld", row, _messageAry.count);
    //    }
    return nil;
}


#pragma mark - lazy loading

- (RecommendViewModel*)recomendViewModel{
    
    if (!_recomendViewModel) {
        _recomendViewModel = [RecommendViewModel new];
    }
    return _recomendViewModel;
}


- (ReTableViewModel*)reTableViewModel{
    
    if (!_reTableViewModel) {
        _reTableViewModel = [ReTableViewModel new];
    }
    return _reTableViewModel;
}


@end
