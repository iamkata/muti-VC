//
//  FindVCtr.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import "FindVCtr.h"

@interface FindVCtr ()

@end

@implementation FindVCtr

/*
 NavBar
 tabbar
 
 正确的设置 self.navigationItem.title来操作（因为self.title操作会影响tabbar的item）
 tabbar（记得隐藏，因为爷控制器是tabbarViewCtr（儿的所有控制器默认都能看到tabbar））
 
 正确的设置 self.tabBarController.title来操作（如果self.title操作会影响tabbar的item，但对nabbar没有效果，因为导航条属于爷控制器）
 navbar（记得刷新，共享了一个navbar）
 */
- (void)viewDidLoad {

    [super viewDidLoad];
 //    self.title = @"发现";
 //   self.navigationItem.title = @"发现";
    
    //self.tabBarController.title = @"发现";
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    /*
     如果 self.tabBarController 在一个 UITabBarController多控制器（ATabbarVCtr）里面，那么self.tabBarController.title操作对这个ATabbarVCtr的tabbarItem的title有影响
     */
    self.tabBarController.title = @"发现";
    //self.title = @"发现";
}

@end
