//
//  MenuR.h
//  EOCCarClass
//
//  Created by sy on 2017/10/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MenuR : NSObject


- (void)perferm:(id)target sel:(SEL)sel arg:(id)arg;
- (void)perferm:(id)target sel:(SEL)sel;

@end
