//
//  MenuR.m
//  EOCCarClass
//
//  Created by sy on 2017/10/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "MenuR.h"

@implementation MenuR

- (void)perferm:(id)target sel:(SEL)sel arg:(id)arg{
    
    [target performSelector:sel withObject:arg];
}


- (void)perferm:(id)target sel:(SEL)sel{
    
    
}

@end
