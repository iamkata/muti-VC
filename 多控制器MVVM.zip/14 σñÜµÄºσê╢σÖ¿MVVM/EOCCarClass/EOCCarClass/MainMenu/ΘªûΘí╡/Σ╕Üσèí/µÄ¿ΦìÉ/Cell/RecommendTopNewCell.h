//
//  RecommendTopNewCell.h
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecommendTopNewCell : UITableViewCell{
    
    IBOutlet UILabel *_topicLb;
    IBOutlet UIImageView *_oneImageV;
    IBOutlet UIImageView *_twoImageV;
    IBOutlet UIImageView *_thrImageV;
    IBOutlet UILabel *_commentCountLb;
    IBOutlet UILabel *_dateLb;
    
}

+ (CGFloat)cellHeight;

@property (nonatomic, strong)NSDictionary *infoDict;

@end
