//
//  MainRoute.m
//  EOCCarClass
//
//  Created by sy on 2017/10/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "MainRoute.h"
#import <UIKit/UIKit.h>

@implementation MainRoute


- (void)skipToMenu:(NSNumber*)index{
    
    UINavigationController *target = (UINavigationController*)[UIApplication sharedApplication].keyWindow.rootViewController;
    target = [target.viewControllers firstObject];
    SEL sel = NSSelectorFromString(@"skipToMenuIndex:");
    
    if ([target respondsToSelector:sel]) {
        
        [target performSelector:sel withObject:index];
        
    }else{
        
        NSLog(@"异常 target 找不到 skipToMenuIndex：");
    }
}

@end
