//
//  HomePageVCtr.h
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//
/*

 */
#import <UIKit/UIKit.h>

#define TitleScrollButtonTag_Start 100

@interface HomePageVCtr : UIViewController{
    
    IBOutlet UIView *_NavView;
    IBOutlet UIScrollView *_titleScrollView;
    IBOutlet UILabel *_lineLb;
    IBOutlet UIScrollView *_contentScrolView;
    
    NSMutableArray *_topicAry;
    UIButton *_currentButton;
}

- (IBAction)selectMoreEvent:(UIButton*)sender;
- (IBAction)searchEvent:(UIButton*)sender;

@end
