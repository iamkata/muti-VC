//
//  HomePageVCtr.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//  MVCS  

#import "HomePageVCtr.h"
#import "RecommendVCtr.h"
#import "ReMenuMoreVCtr.h"

@interface HomePageVCtr (){
    RecommendVCtr *_recommendVCtr;
    ReMenuMoreVCtr *_reMenuMoreVCtr;
}

@end

@implementation HomePageVCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"首页";
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    _topicAry = [NSMutableArray arrayWithObjects:@"推荐",@"优创+",@"视频",@"快报",@"游记",@"图片",@"行情",@"新闻",@"原创",@"说客",@"评测",@"导购", nil];

    float titleBtWidth = 60;
    for (int i = 0; i < _topicAry.count; i++) {
        
        UIButton *titleBt = [UIButton buttonWithType:UIButtonTypeCustom];
        [titleBt setFrame:CGRectMake(i*titleBtWidth, 0, titleBtWidth, _titleScrollView.frame.size.height)];
        [titleBt setTitle:_topicAry[i] forState:UIControlStateNormal];
        titleBt.titleLabel.font = [UIFont systemFontOfSize:16];
        [titleBt setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        [titleBt setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [titleBt setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
        [titleBt addTarget:self action:@selector(pressTitleButton:) forControlEvents:UIControlEventTouchUpInside];
        [_titleScrollView addSubview:titleBt];
        titleBt.tag = TitleScrollButtonTag_Start + i;
        if (i == 0) {
            _currentButton = titleBt;
            _currentButton.selected = YES;
            _lineLb.center = CGPointMake(_currentButton.center.x, _lineLb.center.y);
        }
    }
    
    [_titleScrollView setContentSize:CGSizeMake(titleBtWidth*_topicAry.count, _titleScrollView.frame.size.height)];
  
    _recommendVCtr = [[RecommendVCtr alloc] initWithNibName:@"RecommendVCtr" bundle:nil];
    [_recommendVCtr.view setFrame:CGRectMake(0, 0, _contentScrolView.frame.size.width, _contentScrolView.frame.size.height)];
    
    [_contentScrolView addSubview:_recommendVCtr.view];
    [self addChildViewController:_recommendVCtr];
    
    _contentScrolView.pagingEnabled = YES;
    [_contentScrolView setContentSize:CGSizeMake(_contentScrolView.frame.size.width *5, _contentScrolView.frame.size.height)];
 
    
    _reMenuMoreVCtr = [ReMenuMoreVCtr new];
    [self.view addSubview:_reMenuMoreVCtr.view];
    _reMenuMoreVCtr.view.hidden = YES;
    [self addChildViewController:_reMenuMoreVCtr];
    
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewWillLayoutSubviews{
    
    [super viewWillLayoutSubviews];
    
    _reMenuMoreVCtr.view.frame = CGRectMake(0, 80, self.view.frame.size.width, self.view.frame.size.height);
    
}

#pragma mark - Button Event

- (void)pressTitleButton:(UIButton*)sender{
    
    if (_currentButton != sender) {
        _currentButton.selected = NO;
        _currentButton = sender;
    }
    _currentButton.selected = YES;
    _lineLb.center = CGPointMake(_currentButton.center.x, _lineLb.center.y);
    [self fitTitleScrollViewPosition];
    
    _reMenuMoreVCtr.view.hidden = YES;

}

- (IBAction)selectMoreEvent:(UIButton*)sender{
    _reMenuMoreVCtr.view.hidden = NO;
}

- (IBAction)searchEvent:(UIButton*)sender{
    
}

- (void)fitTitleScrollViewPosition{

}

#pragma mark - scrollview delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    int page = scrollView.contentOffset.x/ScreenWidth;
    _currentButton.selected = NO;
    _currentButton = [_titleScrollView viewWithTag:TitleScrollButtonTag_Start+page];
    _currentButton.selected = YES;
    _lineLb.center = CGPointMake(_currentButton.center.x, _lineLb.center.y);
    
    [self fitTitleScrollViewPosition];
}

@end
