//
//  MessageModel.h
//  EOCCarClass
//
//  Created by EOC on 2017/6/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MessageModel : NSObject

@property (nonatomic, strong)NSString *messageId;
@property (nonatomic, strong)NSString *messageTitle;//标题
@property (nonatomic, strong)NSString *statusStr; // 是否头条／重播／
@property (nonatomic, strong)NSString *commentCount;//评论数
@property (nonatomic, strong)NSString *fromCompany;//来自哪个 如66车讯／车视集
@property (nonatomic, assign)int layoutStyle; // 左右布局／上下布局


@property (nonatomic, assign)float messageHeight;

@end
