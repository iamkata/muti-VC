//
//  RecommendCell.h
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MessageModel;

@interface RecommendCell : UITableViewCell{
    
    IBOutlet UILabel *_contentLb;
    IBOutlet UILabel *_readCountLb;
    IBOutlet UILabel *_timeLb;
    IBOutlet UIImageView *_imageV;
}

@property (nonatomic, strong)MessageModel *messageModel;


+ (CGFloat)cellHeight;

@end
