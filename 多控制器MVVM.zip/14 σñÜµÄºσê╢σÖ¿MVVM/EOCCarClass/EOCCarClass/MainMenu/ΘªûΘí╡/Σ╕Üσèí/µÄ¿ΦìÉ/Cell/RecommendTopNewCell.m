//
//  RecommendTopNewCell.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import "RecommendTopNewCell.h"

@implementation RecommendTopNewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
}

+ (CGFloat)cellHeight{
    return 105.0;
}


- (void)setInfoDict:(NSDictionary *)infoDict{
    
    _infoDict = infoDict;
    
}

@end
