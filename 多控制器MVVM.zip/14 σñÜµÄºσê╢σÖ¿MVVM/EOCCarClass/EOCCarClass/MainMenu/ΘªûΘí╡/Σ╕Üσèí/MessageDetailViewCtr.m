//
//  MessageDetailViewCtr.m
//  EOCCarClass
//
//  Created by EOC on 2017/6/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "MessageDetailViewCtr.h"
#import "RecommendVCtr.h"
//#import "MainRoute.h"
#import "MenuR.h"

@interface MessageDetailViewCtr ()

@property (nonatomic, strong)NSString *messageId;

@end

@implementation MessageDetailViewCtr

- (instancetype)initWithMessageID:(NSString*)messsgeId{
    
    self = [super init];
    if (self) {
        _messageId = messsgeId;
    }
    return self;
    
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
   
    self.title = @"详情页";
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    
    MenuR *mr = [MenuR new];
    [mr perferm:[NSClassFromString(@"MainRoute") new] sel:@selector(skipToMenu:) arg:[NSNumber numberWithInt:2]];
    
//    [MainRoute skipToMenu:2];
//    RecommendVCtr *recommendVCtr = [RecommendVCtr new];
//    [self.navigationController pushViewController:recommendVCtr animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}



@end
