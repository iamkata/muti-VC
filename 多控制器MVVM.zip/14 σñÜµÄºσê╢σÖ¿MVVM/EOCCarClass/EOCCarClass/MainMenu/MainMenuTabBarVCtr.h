//
//  MainMenuTabBarVCtr.h
//  EOCCarClass
//
//  Created by EOC on 2017/6/15.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomePageVCtr.h"
#import "ForumVCtr.h"
#import "SelectCarVCtr.h"
#import "FindVCtr.h"
#import "UserInfoVCtr.h"

/*
 多控制器容器
 包含关系
 怎么处理这个业务hidesBottomBarWhenPushed
 不想到每一个业务来单独处理，有没有统一处理的方式
 */

@interface MainMenuTabBarVCtr : UITabBarController{
    
    HomePageVCtr  *_eocHomePageVC;
    ForumVCtr     *_eocForumVC;
    SelectCarVCtr *_eocSelectCarVC;
    FindVCtr      *_eocFinderVC;
    UserInfoVCtr  *_eocUserInfoVC;
    
    
    UIView *_eocTabBar;
    
    NSArray *tabbarTitleAry;
    NSArray *tabbarTitleImageAry;
    NSArray *tabbarTitleHightImageAry;
}


@end
