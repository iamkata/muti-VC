//
//  TabBarButtton.m
//  EOCCarClass
//
//  Created by EOC on 2017/6/15.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "TabBarButtton.h"

@implementation TabBarButtton

- (void)layoutSubviews{

    [super layoutSubviews];
    
    float imageWidth  = 64;
    float imageheight = 50;
    
    self.titleLabel.hidden = YES;
    [self.imageView setFrame:CGRectMake(0, (self.frame.size.width-imageWidth)/2, imageWidth, imageheight)];
    
}

@end
