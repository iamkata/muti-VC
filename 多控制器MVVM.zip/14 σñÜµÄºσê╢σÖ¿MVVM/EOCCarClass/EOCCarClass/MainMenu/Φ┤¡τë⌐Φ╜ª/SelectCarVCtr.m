//
//  SelectCarVCtr.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import "SelectCarVCtr.h"
/*
 导航条 切换控制器的时候，刷新导航条
 tabbar
 */

@interface SelectCarVCtr ()

@end

@implementation SelectCarVCtr

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.title = @"购物车";
    
    self.navigationItem.title = @"购物车";
}

@end
