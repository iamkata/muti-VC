//
//  ReTableViewModel.m
//  EOCCarClass
//
//  Created by sy on 2017/10/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "ReTableViewModel.h"
#import "RecommendCell.h"

@implementation ReTableViewModel{
    UITableView *_tableview;
}


#pragma mark - tableview delegate

- (void)configTable:(UITableView*)tableView{
    
    _tableview = tableView;
    tableView.delegate = self;
    tableView.dataSource = self;
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    // return [RecommendCell cellHeight];
    return 80.0;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.rowNumber;
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    RecommendCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RecommendCell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"RecommendCell" owner:nil options:nil] firstObject];
    }
    
   // cell.messageModel = [self messageModelForRow:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
   // [self.recomendViewModel pushMessageDetailIndex:indexPath viewCtr:self];
}


- (MessageModel*)messageModelForRow:(NSInteger)row{
    
//    if (row < self.messageAry.count) {
//        return self.messageAry[row];
//    }else{
//        NSLog(@"row越界messageAry：%ld--%ld", row, _messageAry.count);
//    }
    return nil;
}

@end
