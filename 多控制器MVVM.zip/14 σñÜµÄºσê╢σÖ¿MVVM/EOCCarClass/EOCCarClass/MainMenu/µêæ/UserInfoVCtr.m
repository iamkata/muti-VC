//
//  UserInfoVCtr.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import "UserInfoVCtr.h"

@interface UserInfoVCtr ()

@end

@implementation UserInfoVCtr

- (void)viewDidLoad {
    
    [super viewDidLoad];
   // self.navigationItem.title = @"我";
    self.title = @"我";
    
}

@end
