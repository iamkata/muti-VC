//
//  RecommendViewModel.m
//  EOCCarClass
//
//  Created by EOC on 2017/6/15.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "RecommendViewModel.h"
#import "MessageModel.h"
#import "MessageDetailViewCtr.h"

@interface RecommendViewModel (){
    
    
}
@property (nonatomic, strong)NSMutableArray *messageAry;
@end

@implementation RecommendViewModel

/*
 
 */

- (NSInteger)rowNumber{
    
    return self.messageAry.count;
}

- (CGFloat)messageHeightForRow:(NSInteger)row{
    if (row < self.messageAry.count){
        MessageModel *messageModel = self.messageAry[row];
        return messageModel.messageHeight;
    }
    return 0;
}


- (MessageModel*)messageModelForRow:(NSInteger)row{
    
    if (row < self.messageAry.count) {
        return self.messageAry[row];
    }else{
        NSLog(@"row越界messageAry：%ld--%ld", row, _messageAry.count);
    }
    return nil;
}


- (NSString*)messageIdForRow:(NSInteger)row{
    
    if (row < self.messageAry.count) {
        MessageModel *messageModel = self.messageAry[row];
        return messageModel.messageId;
    }else{
        NSLog(@"row越界messageAry：%ld--%ld", row, _messageAry.count);
    }
    return nil;
    
}


- (void)deleteAdView:(UIView*)deleteView headView:(UIView*)headView tableview:(UITableView*)tableView{
    
    [deleteView removeFromSuperview];
    headView.frame = ({
        CGRect frame = headView.frame;
        frame.size.height = frame.size.height - deleteView.frame.size.height;
        frame;
    });
    [tableView setTableHeaderView:nil];
    [tableView setTableHeaderView:deleteView];
    
}

- (void)pushMessageDetailIndex:(NSIndexPath *)indexPath viewCtr:(UIViewController*)targetVCtr{
    
    MessageDetailViewCtr *messageDetailVCtr = [[MessageDetailViewCtr alloc] initWithMessageID:[self messageIdForRow:indexPath.row]];
    
    [targetVCtr.navigationController pushViewController:messageDetailVCtr animated:YES];
    
}


- (void)loadDatafromNetWithPage:(NSInteger)page finishNet:(finishLoadBlock)finishBlock{
    
    
    for (int i = 0; i< 10; i++) {
        
        MessageModel *messageModel = [MessageModel new];
        messageModel.messageTitle = [NSString stringWithFormat:@"消息：：%d", i];
        [self.messageAry addObject:messageModel];
        
    }
    
    finishBlock(nil);
}

#pragma mark - lazy loading

- (NSMutableArray*)messageAry{
    if (!_messageAry) {
        _messageAry = [NSMutableArray array];
    }
    return _messageAry;
}


@end
