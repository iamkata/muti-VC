//
//  RecommendViewModel.h
//  EOCCarClass
//
//  Created by EOC on 2017/6/15.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class MessageModel;

typedef void(^finishLoadBlock)(id infoDict);

@interface RecommendViewModel : NSObject


@property(nonatomic, assign) NSInteger rowNumber;


- (CGFloat)messageHeightForRow:(NSInteger)row;

- (MessageModel*)messageModelForRow:(NSInteger)row;

- (NSString*)messageIdForRow:(NSInteger)row;


- (void)loadDatafromNetWithPage:(NSInteger)page finishNet:(finishLoadBlock)finishBlock;

- (void)deleteAdView:(UIView*)deleteView headView:(UIView*)headView tableview:(UITableView*)tableView;

- (void)pushMessageDetailIndex:(NSIndexPath *)indexPath viewCtr:(UIViewController*)targetVCtr;

@end
