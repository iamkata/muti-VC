//
//  AppDelegate.m
//  EOCCarClass
//
//  Created by EOC on 2017/6/15.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "AppDelegate.h"
#import "MainMenuTabBarVCtr.h"

@interface AppDelegate (){
    UIWindow *eocWindow;
}

@end

@implementation AppDelegate

/*
 
 登录界面，如果没有保存登录账号和密码，那么第一个界面登录界面，
 如果保存了登录账号和密码，直接显示主页
 
 第一个界面不确定的话，不要修改window的根控制器（不要修改框架结构）；
 判断是否push／present登录界面（如果展示就利用启动页延时）
 
 如果跟控制不确定，后面很多逻辑都要加if或者判断 （打个比方，回到mainMenuTabBarVCtr的主页）
 */

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    
    //[self styleOne];
    [self styleTwo];

    //[self delayLaunchImage];
    
    return YES;
}

- (void)cancelLaunImage{
    
    [eocWindow resignKeyWindow];
    eocWindow = nil;
}

// 耦合度比较低
- (void)delayLaunchImage{
    
    eocWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    eocWindow.rootViewController = [UIViewController new];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [imageView setImage:[UIImage imageNamed:@"11.PNG"]];
    [eocWindow addSubview:imageView];
    [eocWindow makeKeyAndVisible];
    
    [self performSelector:@selector(cancelLaunImage) withObject:nil afterDelay:5];
}

- (void)styleOne{
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    
    MainMenuTabBarVCtr *mainMenuTabBarVCtr = [[MainMenuTabBarVCtr alloc] init];
    self.window.rootViewController = mainMenuTabBarVCtr;
    
    [self.window makeKeyAndVisible];
}

- (void)styleTwo{
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    
    MainMenuTabBarVCtr *mainMenuTabBarVCtr = [[MainMenuTabBarVCtr alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:mainMenuTabBarVCtr];
    self.window.rootViewController = nav;
    
    [self.window makeKeyAndVisible];
}

@end
