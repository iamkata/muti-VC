//
//  MessageModel.m
//  EOCCarClass
//
//  Created by EOC on 2017/6/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "MessageModel.h"

@implementation MessageModel


- (float)messageHeight{
    
    return 80.0;
}

@end
