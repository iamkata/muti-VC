//
//  RecommendCell.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import "RecommendCell.h"
#import "MessageModel.h"

@implementation RecommendCell

- (void)awakeFromNib {
    
    [super awakeFromNib];
    
}


- (void)setMessageModel:(MessageModel *)messageModel{
    
    _messageModel = messageModel;
    
    _contentLb.text = messageModel.messageTitle;
    
}

+ (CGFloat)cellHeight{
    
    return 80.0;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
}

@end
