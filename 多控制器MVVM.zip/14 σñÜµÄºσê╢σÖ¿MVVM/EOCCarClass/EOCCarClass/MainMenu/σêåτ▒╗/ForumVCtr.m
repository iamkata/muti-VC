//
//  ForumVCtr.m
//  EOCCarHome
//
//  Created by class on 10/10/2017.
//  Copyright © 2017 八点钟学院. All rights reserved.
//

#import "ForumVCtr.h"
#import "RecommendVCtr.h"

@interface ForumVCtr ()

@end

@implementation ForumVCtr

- (void)viewDidLoad {
    
    [super viewDidLoad];
   // self.title = @"分类";
    
    //self.navigationItem.title = @"分类";
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    self.tabBarController.title = @"分类";
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    
}

@end
