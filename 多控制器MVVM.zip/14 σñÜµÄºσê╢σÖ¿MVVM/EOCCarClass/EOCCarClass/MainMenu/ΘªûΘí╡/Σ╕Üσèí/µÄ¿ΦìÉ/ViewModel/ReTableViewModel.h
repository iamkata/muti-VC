//
//  ReTableViewModel.h
//  EOCCarClass
//
//  Created by sy on 2017/10/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ReTableViewModel : NSObject<UITableViewDelegate, UITableViewDataSource>

@property(nonatomic, assign) NSInteger rowNumber;


- (void)configTable:(UITableView*)tableView;

@end
