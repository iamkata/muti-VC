//
//  MainMenuTabBarVCtr.m
//  EOCCarClass
//
//  Created by EOC on 2017/6/15.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "MainMenuTabBarVCtr.h"
#import "TabBarButtton.h"
#import "EOCBaseNavCtr.h"

@interface MainMenuTabBarVCtr (){
    
    TabBarButtton *_selectTabBarBt;
    UIImageView *_defultImage;
}

@end

@implementation MainMenuTabBarVCtr

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        tabbarTitleAry = [NSArray arrayWithObjects:@"首页", @"论坛", @"发现", @"选车", @"我", nil];
        tabbarTitleImageAry = [NSArray arrayWithObjects:@"tabBar_home_normal.png",@"tabBar_category_normal.png", @"tabBar_find_normal.png", @"tabBar_cart_normal.png", @"tabBar_myJD_normal.png", nil];
        tabbarTitleHightImageAry = [NSArray arrayWithObjects:@"tabBar_home_press.png", @"tabBar_category_press.png", @"tabBar_find_press.png", @"tabBar_cart_press.png",@"tabBar_myJD_press.png", nil];
        
        _eocHomePageVC  = [[HomePageVCtr alloc] init];
        _eocForumVC     = [[ForumVCtr alloc] init];
        _eocFinderVC    = [[FindVCtr alloc] init];
        _eocSelectCarVC = [[SelectCarVCtr alloc] init];
        _eocUserInfoVC  = [[UserInfoVCtr alloc] init];
        
       // [self styleOne];
        [self styleTwo];
        
    }
    
    self.selectedIndex = 0;
    return self;
    
}

- (void)styleOne{
    
    UINavigationController *navHome = [[EOCBaseNavCtr alloc] initWithRootViewController:_eocHomePageVC];
    UINavigationController *navForum = [[EOCBaseNavCtr alloc] initWithRootViewController:_eocForumVC];
    UINavigationController *navSelectCar = [[EOCBaseNavCtr alloc] initWithRootViewController:_eocSelectCarVC];
    UINavigationController *navFinder = [[EOCBaseNavCtr alloc] initWithRootViewController:_eocFinderVC];
    UINavigationController *navUserInfo = [[EOCBaseNavCtr alloc] initWithRootViewController:_eocUserInfoVC];
    
    self.viewControllers = [NSArray arrayWithObjects:navHome, navForum, navFinder,navSelectCar , navUserInfo, nil];;
}

- (void)styleTwo{
    
    self.viewControllers = [NSArray arrayWithObjects:_eocHomePageVC, _eocForumVC, _eocFinderVC,_eocSelectCarVC , _eocUserInfoVC, nil];;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
}


- (void)viewDidLayoutSubviews{
    
    [super viewDidLayoutSubviews];
    if (!_eocTabBar) {
        [self createEocTabBar];
    }
}

- (void)skipToMenuIndex:(NSNumber*)indexN{
    
    NSInteger index = [indexN integerValue];
    [self.navigationController popToRootViewControllerAnimated:YES];
    //self.selectedIndex = index;
    [self selectMenuVC:[_eocTabBar viewWithTag:index]];
}


- (void)createEocTabBar{
    float tabbarWidth  = self.tabBar.frame.size.width;
    float tabbarHeight = self.tabBar.frame.size.height;
    _eocTabBar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tabbarWidth, tabbarHeight)];
    _eocTabBar.backgroundColor = [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    
    float tabbarItemWidth = tabbarWidth/tabbarTitleAry.count;
    for (NSInteger i = 0; i < tabbarTitleAry.count; i++){
        
        TabBarButtton *tabbarBt = [[TabBarButtton alloc] init];
        [tabbarBt setFrame:CGRectMake(i*tabbarItemWidth, 0, tabbarItemWidth, tabbarHeight)];
        [tabbarBt addTarget:self action:@selector(selectMenuVC:) forControlEvents:UIControlEventTouchUpInside];
        tabbarBt.tag = i;
        
        [tabbarBt setBackgroundImage:[UIImage imageNamed:tabbarTitleImageAry[i]] forState:UIControlStateNormal];
        [tabbarBt setBackgroundImage:[UIImage imageNamed:tabbarTitleHightImageAry[i]] forState:UIControlStateSelected];
        
        [_eocTabBar addSubview:tabbarBt];
        if (i == 0) {
            _selectTabBarBt = tabbarBt;
            _selectTabBarBt.selected = YES;
        }
    }
    
    [self tabbarStyleOne];
    //[self tabbarStyleTwo];
}

//清空子控件
- (void)tabbarStyleOne{
    // tabbar 原生子试图 all remove
    NSArray *tabbarViewsAry = [self.tabBar subviews];
    for (int i = 0; i < tabbarViewsAry.count; i++) {
        UIView *view = tabbarViewsAry[i];
        [view removeFromSuperview];
    }
    
    [self.tabBar insertSubview:_eocTabBar atIndex:0];
}

//直接移除
- (void)tabbarStyleTwo{
    
    // 直接remove tabbar
    UIView *superV = [self.tabBar superview];
    _eocTabBar.frame = self.tabBar.frame;
    [self.tabBar removeFromSuperview];
    [superV addSubview:_eocTabBar];
    
}

- (void)selectMenuVC:(TabBarButtton*)sender{
    
    if (self.selectedIndex == sender.tag) {
        return;
    }
    
    self.selectedIndex = sender.tag;
    _selectTabBarBt.selected = NO;
    _selectTabBarBt = sender;
    _selectTabBarBt.selected = YES;
    
}

@end
