//
//  MessageDetailViewCtr.h
//  EOCCarClass
//
//  Created by EOC on 2017/6/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MessageModel;

@interface MessageDetailViewCtr : UIViewController





- (instancetype)initWithMessageID:(NSString*)messsgeId;

@end
